
package salsa.language.exceptions;

public class RunTimeException extends SalsaException{
    public RunTimeException(){
	super();
    }
    public RunTimeException(String detail){
	super(detail);
    }
}
