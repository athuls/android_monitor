Running examples.messenger

Execute examples.messenger.Sender:
java examples.messanger.Sender