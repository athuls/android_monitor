package salsac;

public class Symbol {
	public String name;
	public String type;
	
	public Symbol(String _name, String _type) {
		name = _name;
		type = _type;
	}
}