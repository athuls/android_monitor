
package salsa.language.exceptions;

public class CurrentContinuationException extends RuntimeException {
    public CurrentContinuationException() {
	super();
    }
}
